﻿---
type: code-exercise
tags: []
difficulty: beginner
language:
linked-concept:
created: {{date}}
---

# Exercise: {{title}}

## Goal
[What this exercise teaches]

## File
03-code/python/exercises/{{filename}}.py

## Instructions
1. Step 1
2. Step 2

## Expected Output
[expected output here]
