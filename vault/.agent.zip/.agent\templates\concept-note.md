﻿---
type: concept
tags: []
difficulty: beginner
language:
domain:
created: {{date}}
---

# {{title}}

> One-liner: what this is in one sentence.

## Mental Model
[The intuition. How to think about this.]

## Quick Facts
- Fact 1
- Fact 2

## Code Example
\\\python
# example
\\\

## Related
- [[link-1]]
- [[link-2]]

## Deep Dive
[Optional: longer explanation or external links]
